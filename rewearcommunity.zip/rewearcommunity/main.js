
const items = [
    {
        title: "Blue T-shirt",
        size: "M",
        image: "images/tshirt.png",
        description: "Lightly used, great condition"
    },
    {
        title: "Denim Jacket",
        size: "L",
        image: "images/jacket.png",
        description: "Warm and stylish"
    }
];

const itemGrid = document.getElementById("itemGrid");

items.forEach(item => {
    const card = document.createElement("div");
    card.className = "item-card";
    card.innerHTML = `
        <img src="${item.image}" alt="${item.title}">
        <div class="content">
            <h3>${item.title}</h3>
            <p>Size: ${item.size}</p>
            <p>${item.description}</p>
            <button>Request Swap</button>
        </div>
    `;
    itemGrid.appendChild(card);
});